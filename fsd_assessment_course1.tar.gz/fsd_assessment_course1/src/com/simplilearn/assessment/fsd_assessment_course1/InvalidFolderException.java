package com.simplilearn.assessment.fsd_assessment_course1;

public class InvalidFolderException extends Exception {
	
	public InvalidFolderException( ) {
		super();
	}

}

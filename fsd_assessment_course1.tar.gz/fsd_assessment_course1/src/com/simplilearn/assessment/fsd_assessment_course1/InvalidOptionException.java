package com.simplilearn.assessment.fsd_assessment_course1;


public class InvalidOptionException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidOptionException( int selectedOption) {
		super();
	}
	
}
